export class Car {
  constructor(
    model: string,
    price: number,
    id?:   number) {}
}
