# angular-with_php_backend
Angular app with PHP backend

Accompanies the tutorial at https://goo.gl/jZ4UAa "Learn to code Angular app with PHP backend"

Compatible with PHP 7 and Angular 7
